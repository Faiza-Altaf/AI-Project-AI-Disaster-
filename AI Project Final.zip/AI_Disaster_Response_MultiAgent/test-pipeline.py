from backend.workflow.graph import run_disaster_response

if __name__ == "__main__":
    incident = input("Enter incident report: ")
    result = run_disaster_response(incident)

    print("\n" + "=" * 60)
    print("INCIDENT ANALYSIS")
    print("=" * 60)
    print(result.get("incident_analysis", "N/A"))

    print("\n" + "=" * 60)
    print("RESCUE PLAN")
    print("=" * 60)
    print(result.get("rescue_plan", "N/A"))

    print("\n" + "=" * 60)
    print("HOSPITAL PLAN")
    print("=" * 60)
    print(result.get("hospital_plan", "N/A"))

    print("\n" + "=" * 60)
    print("LOCATION PLAN")
    print("=" * 60)
    print(result.get("location_plan", "N/A"))

    print("\n" + "=" * 60)
    print("RESOURCE PLAN")
    print("=" * 60)
    print(result.get("resource_plan", "N/A"))

    print("\n" + "=" * 60)
    print("RETRIEVED SOPs")
    print("=" * 60)
    print(result.get("retrieved_sops", "N/A"))

    print("\n" + "=" * 60)
    print("FINAL VERIFIED RESPONSE")
    print("=" * 60)
    print(result.get("final_response", "N/A"))