import os
import streamlit as st
from dotenv import load_dotenv

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI

# Pinecone (community wrapper — no langchain-pinecone/simsimd dependency needed)
from langchain_community.vectorstores import Pinecone
from pinecone import Pinecone as PineconeClient

# Standard LCEL Imports
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

# 1. Environment Variables Load
load_dotenv()

# 2. Page Configuration
st.set_page_config(
    page_title="Disaster Response Multi-Agent System",
    page_icon="🤖",
    layout="wide"
)

# Custom Glassmorphic Dark UI (CSS)
custom_css = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

    .stApp {
        background: radial-gradient(circle at 20% 0%, #161b2e 0%, #0e1117 45%, #0a0c10 100%);
        font-family: 'Inter', sans-serif;
    }

    /* Header */
    .main-title {
        background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 50%, #EC4899 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 2.6rem !important;
        font-weight: 800;
        margin-bottom: 0.2rem;
        letter-spacing: -0.02em;
    }
    .sub-title {
        color: #9CA3AF;
        font-size: 1.05rem;
        margin-bottom: 1.6rem;
        max-width: 640px;
        line-height: 1.5;
    }

    /* Section labels */
    .section-label {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #E5E7EB;
        font-size: 1.05rem;
        font-weight: 700;
        margin: 0 0 0.9rem 0;
    }

    /* Card container */
    .custom-card {
        background: rgba(255, 255, 255, 0.035);
        border-radius: 16px;
        padding: 24px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(12px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
        margin-bottom: 24px;
        transition: border-color 0.2s ease;
    }
    .custom-card:hover {
        border-color: rgba(124, 58, 237, 0.35);
    }

    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%) !important;
        color: white !important;
        border-radius: 10px !important;
        border: none !important;
        padding: 0.65rem 1.3rem !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 14px rgba(124, 58, 237, 0.35);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .stButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 18px rgba(124, 58, 237, 0.5);
    }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background-color: #12161f;
        border-right: 1px solid rgba(255, 255, 255, 0.06);
    }
    section[data-testid="stSidebar"] .stTextInput input {
        background-color: #1a1f2b;
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: #E5E7EB;
        border-radius: 8px;
    }

    /* Status badges */
    .badge-ready {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background-color: rgba(16, 185, 129, 0.12);
        color: #10B981;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        border: 1px solid rgba(16, 185, 129, 0.3);
        margin-top: 8px;
    }

    /* File uploader */
    [data-testid="stFileUploaderDropzone"] {
        background-color: rgba(255, 255, 255, 0.02) !important;
        border: 1.5px dashed rgba(124, 58, 237, 0.4) !important;
        border-radius: 12px !important;
    }

    /* Chat bubbles */
    [data-testid="stChatMessage"] {
        background: rgba(255, 255, 255, 0.03);
        border-radius: 14px;
        border: 1px solid rgba(255, 255, 255, 0.06);
    }
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

# UI Header
st.markdown('<h1 class="main-title">🚨 Disaster Response Multi-Agent System</h1>', unsafe_allow_html=True)
st.markdown(
    '<p class="sub-title">Upload emergency SOPs or incident reports, and get AI-assisted '
    'response guidance grounded in retrieved SOP documents — powered by Gemini and Pinecone.</p>',
    unsafe_allow_html=True
)

# 3. Sidebar API Configuration
with st.sidebar:
    st.markdown("<h3 style='color: #F3F4F6;'>⚙️ Configuration</h3>", unsafe_allow_html=True)

    default_google_key = os.getenv("GOOGLE_API_KEY", "")
    default_pinecone_key = os.getenv("PINECONE_API_KEY", "")
    default_index_name = os.getenv("PINECONE_INDEX_NAME", "rag-index")

    google_api_key = st.text_input("Google AI Studio API Key", value=default_google_key, type="password")
    pinecone_api_key = st.text_input("Pinecone API Key", value=default_pinecone_key, type="password")
    index_name = st.text_input("Pinecone Index Name", value=default_index_name)

if not google_api_key or not pinecone_api_key:
    st.info("👈 Please enter your Google & Pinecone API Keys in the sidebar to proceed.", icon="🔑")
    st.stop()

# 4. Session State Setup
if "messages" not in st.session_state:
    st.session_state.messages = []

if "vector_store" not in st.session_state:
    st.session_state.vector_store = None

# 5. Document Processing Section
st.markdown('<div class="custom-card">', unsafe_allow_html=True)
st.markdown('<p class="section-label">📄 Upload &amp; Index Emergency SOP</p>', unsafe_allow_html=True)

uploaded_file = st.file_uploader("Choose an SOP PDF file", type=["pdf"], label_visibility="collapsed")

if uploaded_file is not None:
    if st.button("Index Document to Pinecone", type="primary"):
        with st.spinner("Splitting document and generating vector embeddings..."):
            try:
                temp_pdf_path = f"temp_{uploaded_file.name}"
                with open(temp_pdf_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())

                loader = PyPDFLoader(temp_pdf_path)
                documents = loader.load()

                text_splitter = RecursiveCharacterTextSplitter(
                    chunk_size=1000,
                    chunk_overlap=200
                )
                chunks = text_splitter.split_documents(documents)

                embeddings = GoogleGenerativeAIEmbeddings(
                    model="models/gemini-embedding-001",
                    google_api_key=google_api_key,
                    output_dimensionality=1024
                )

                # Initialize Pinecone Client directly
                pc = PineconeClient(api_key=pinecone_api_key)

                # Store documents using LangChain Community Vectorstore
                vector_store = Pinecone.from_documents(
                    documents=chunks,
                    embedding=embeddings,
                    index_name=index_name
                )

                st.session_state.vector_store = vector_store
                st.markdown(
                    f'<span class="badge-ready">✓ Indexed {len(chunks)} Chunks Successfully</span>',
                    unsafe_allow_html=True
                )

                if os.path.exists(temp_pdf_path):
                    os.remove(temp_pdf_path)

            except Exception as e:
                st.error(f"Error processing document: {str(e)}")

st.markdown('</div>', unsafe_allow_html=True)

# 6. Conversational Interface (LCEL RAG Pipeline)
st.markdown('<p class="section-label">💬 Ask Questions</p>', unsafe_allow_html=True)

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if user_query := st.chat_input("Describe the incident or ask about emergency response procedures..."):
    st.session_state.messages.append({"role": "user", "content": user_query})
    with st.chat_message("user"):
        st.markdown(user_query)

    with st.chat_message("assistant"):
        if st.session_state.vector_store is None:
            try:
                embeddings = GoogleGenerativeAIEmbeddings(
                    model="models/gemini-embedding-001",
                    google_api_key=google_api_key,
                    output_dimensionality=1024
                )
                pc = PineconeClient(api_key=pinecone_api_key)
                st.session_state.vector_store = Pinecone.from_existing_index(
                    index_name=index_name,
                    embedding=embeddings
                )
            except Exception:
                st.error("Please upload and index a document first.")
                st.stop()

        with st.spinner("Analyzing context & generating response..."):
            try:
                llm = ChatGoogleGenerativeAI(
                    model="models/gemini-3-flash",
                    google_api_key=google_api_key,
                    temperature=0.3
                )

                retriever = st.session_state.vector_store.as_retriever(
                    search_type="similarity",
                    search_kwargs={"k": 4}
                )

                prompt = ChatPromptTemplate.from_messages([
                    ("system", "You are an AI assistant. Answer the user's question using ONLY the provided context below. If you don't know the answer, state that you cannot find it in the provided documents.\n\nContext:\n{context}"),
                    ("human", "{input}")
                ])

                def format_docs(docs):
                    return "\n\n".join(doc.page_content for doc in docs)

                rag_chain = (
                    {"context": retriever | format_docs, "input": RunnablePassthrough()}
                    | prompt
                    | llm
                    | StrOutputParser()
                )

                answer = rag_chain.invoke(user_query)

                st.markdown(answer)
                st.session_state.messages.append({"role": "assistant", "content": answer})

            except Exception as e:
                st.error(f"Execution Error: {str(e)}")