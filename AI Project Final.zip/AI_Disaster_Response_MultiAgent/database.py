import sqlite3
from datetime import datetime

DB_NAME = "disaster_incidents.db"

def init_db():
    """Database table create karta hai agar pehle se na ho."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            scenario_type TEXT,
            description TEXT NOT NULL,
            severity TEXT NOT NULL,
            action_plan TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def save_incident(scenario_type, description, severity, action_plan):
    """Naya incident record database mein insert karta hai."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''
        INSERT INTO incidents (timestamp, scenario_type, description, severity, action_plan)
        VALUES (?, ?, ?, ?, ?)
    ''', (timestamp, scenario_type, description, severity, action_plan))
    conn.commit()
    conn.close()

def fetch_all_incidents():
    """Saare past incidents history fetch karta hai."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, timestamp, scenario_type, description, severity, action_plan 
        FROM incidents ORDER BY id DESC
    ''')
    rows = cursor.fetchall()
    conn.close()
    return rows
