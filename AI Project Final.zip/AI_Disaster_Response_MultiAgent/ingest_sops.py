import os
from dotenv import load_dotenv
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone

# 1. Load Environment Variables
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_INDEX_NAME = os.getenv("PINECONE_INDEX_NAME")

def ingest_documents(docs_folder="./backend/data/emergency_sops"):
    if not GOOGLE_API_KEY or not PINECONE_API_KEY or not PINECONE_INDEX_NAME:
        print("❌ Error: .env file mein API keys missing hain!")
        return

    print("📄 Loading SOP text files...")
    if not os.path.exists(docs_folder):
        print(f"❌ Error: '{docs_folder}' folder nahi mila!")
        return

    # Text Loader (Directory se sare .txt SOP files load karega)
    loader = DirectoryLoader(
        docs_folder,
        glob="*",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"}
    )
    raw_documents = loader.load()

    if not raw_documents:
        print(f"⚠️ '{docs_folder}' folder mein koi files nahi mili!")
        return

    print(f"✅ {len(raw_documents)} SOP files load ho gaye.")

    # 2. Text Splitting into Chunks
    print("✂️ Splitting text into chunks...")
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len
    )
    documents = text_splitter.split_documents(raw_documents)
    print(f"✅ Total {len(documents)} text chunks tayar hue.")

    # 3. Google GenAI Embeddings Setup
    print("🧠 Generating embeddings using 'gemini-embedding-001'...")
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/gemini-embedding-001",
        google_api_key=GOOGLE_API_KEY,
        output_dimensionality=1024
    )

    # 4. Pinecone Vector Store Upload
    print(f"🚀 Uploading vectors to Pinecone Index: '{PINECONE_INDEX_NAME}'...")
    pc = Pinecone(api_key=PINECONE_API_KEY)

    vector_store = PineconeVectorStore.from_documents(
        documents=documents,
        embedding=embeddings,
        index_name=PINECONE_INDEX_NAME
    )
    print("🎉 Ingestion Complete! Data Pinecone index mein successfully store ho gaya hai.")

if __name__ == "__main__":
    ingest_documents()