import os
import streamlit as st
from dotenv import load_dotenv

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI

# Pinecone (standalone integration package)
from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone as PineconeClient

# Modern Stable LCEL Imports (No C++ dependencies needed)
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

st.set_page_config(page_title="Disaster Response SOP Assistant", page_icon="🚨", layout="wide")

# UI Header
st.title("🚨 Disaster Response SOP Assistant")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuration")
    google_api_key = st.text_input("Google API Key", value=os.getenv("GOOGLE_API_KEY", ""), type="password")
    pinecone_api_key = st.text_input("Pinecone API Key", value=os.getenv("PINECONE_API_KEY", ""), type="password")
    index_name = st.text_input("Pinecone Index Name", value=os.getenv("PINECONE_INDEX_NAME", "rag-index"))

if not google_api_key or not pinecone_api_key:
    st.info("👈 Please enter API Keys in the sidebar to proceed.")
    st.stop()

if "messages" not in st.session_state:
    st.session_state.messages = []

if "vector_store" not in st.session_state:
    st.session_state.vector_store = None

# PDF Processing
uploaded_file = st.file_uploader("Upload an SOP or Incident Document (PDF)", type=["pdf"])

if uploaded_file and st.button("Index into Knowledge Base", type="primary"):
    with st.spinner("Processing & Indexing..."):
        try:
            temp_path = f"temp_{uploaded_file.name}"
            with open(temp_path, "wb") as f:
                f.write(uploaded_file.getbuffer())

            loader = PyPDFLoader(temp_path)
            docs = loader.load()

            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
            chunks = text_splitter.split_documents(docs)

            embeddings = GoogleGenerativeAIEmbeddings(
                model="models/gemini-embedding-001",
                google_api_key=google_api_key,
                output_dimensionality=1024
            )

            pc = PineconeClient(api_key=pinecone_api_key)
            vector_store = PineconeVectorStore.from_documents(
                documents=chunks,
                embedding=embeddings,
                index_name=index_name
            )

            st.session_state.vector_store = vector_store
            st.success(f"Indexed {len(chunks)} Chunks Successfully!")

            if os.path.exists(temp_path):
                os.remove(temp_path)

        except Exception as e:
            st.error(f"Error: {str(e)}")

# Q&A Section
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if user_query := st.chat_input("Describe the incident or ask about response procedures..."):
    st.session_state.messages.append({"role": "user", "content": user_query})
    with st.chat_message("user"):
        st.markdown(user_query)

    with st.chat_message("assistant"):
        if st.session_state.vector_store is None:
            embeddings = GoogleGenerativeAIEmbeddings(
                model="models/gemini-embedding-001",
                google_api_key=google_api_key,
                output_dimensionality=1024
            )
            pc = PineconeClient(api_key=pinecone_api_key)
            st.session_state.vector_store = PineconeVectorStore.from_existing_index(
                index_name=index_name,
                embedding=embeddings
            )

        with st.spinner("Thinking..."):
            try:
                llm = ChatGoogleGenerativeAI(
                    model="models/gemini-3.1-flash-lite",
                    google_api_key=google_api_key,
                    temperature=0.3
                )

                retriever = st.session_state.vector_store.as_retriever(search_kwargs={"k": 4})

                prompt = ChatPromptTemplate.from_messages([
                    ("system", "Answer the question using ONLY the provided context below.\n\nContext:\n{context}"),
                    ("human", "{input}")
                ])

                def format_docs(docs):
                    return "\n\n".join(doc.page_content for doc in docs)

                rag_chain = (
                    {"context": retriever | format_docs, "input": RunnablePassthrough()}
                    | prompt
                    | llm
                    | StrOutputParser()
                )

                answer = rag_chain.invoke(user_query)
                st.markdown(answer)
                st.session_state.messages.append({"role": "assistant", "content": answer})

            except Exception as e:
                st.error(f"Error: {str(e)}")