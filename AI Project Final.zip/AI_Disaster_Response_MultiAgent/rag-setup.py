import os
from dotenv import load_dotenv
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Pinecone as PineconeVectorStore
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from pinecone import Pinecone

# Environment variables load karne ke liye
load_dotenv()

def initialize_rag_vectorstore():
    data_path = os.path.join("data", "disaster_sops.txt")

    if not os.path.exists(data_path):
        raise FileNotFoundError(f"SOP file not found at {data_path}")

    google_api_key = os.getenv("GOOGLE_API_KEY")
    pinecone_api_key = os.getenv("PINECONE_API_KEY")
    index_name = os.getenv("PINECONE_INDEX_NAME")

    if not google_api_key or not pinecone_api_key or not index_name:
        raise EnvironmentError("❌ .env file mein GOOGLE_API_KEY, PINECONE_API_KEY ya PINECONE_INDEX_NAME missing hai!")

    # 1. Load Documents (utf-8 encoding ke sath)
    loader = TextLoader(data_path, encoding="utf-8")
    documents = loader.load()

    # 2. Split Text
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    docs = text_splitter.split_documents(documents)

    # 3. Embeddings Setup
    embeddings = GoogleGenerativeAIEmbeddings(
        model="models/text-embedding-004",
        google_api_key=google_api_key
    )

    # 4. Pinecone Vector Store Upload
    pc = Pinecone(api_key=pinecone_api_key)

    vectorstore = PineconeVectorStore.from_documents(
        documents=docs,
        embedding=embeddings,
        index_name=index_name
    )

    print(f"✅ Pinecone Vectorstore successfully created — '{index_name}' index mein data store ho gaya!")

if __name__ == "__main__":
    initialize_rag_vectorstore()