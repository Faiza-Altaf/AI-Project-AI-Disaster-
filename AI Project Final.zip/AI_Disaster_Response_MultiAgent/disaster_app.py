import streamlit as st

try:
    from streamlit_geolocation import streamlit_geolocation
except ImportError:
    streamlit_geolocation = None

from backend.workflow.graph import run_disaster_response
from database import init_db, save_incident, fetch_all_incidents

st.set_page_config(
    page_title="Disaster Response Multi-Agent System",
    page_icon="🚨",
    layout="wide",
)
init_db()

SCENARIOS = [
    "Chemical / Gas Leak",
    "Fire",
    "Flood",
    "Earthquake / Building Collapse",
    "Medical Emergency",
    "Other",
]
SEVERITIES = ["Low", "Medium", "High", "Critical"]

AGENT_TABS = [
    ("🔎 Analysis", "incident_analysis"),
    ("🚒 Rescue", "rescue_plan"),
    ("🏥 Hospital", "hospital_plan"),
    ("📍 Location", "location_plan"),
    ("📦 Resources", "resource_plan"),
    ("📚 Retrieved SOPs", "retrieved_sops"),
]

st.markdown(
    """
<style>
    .stApp { background: radial-gradient(circle at 15% 0%, #2a1116 0%, #0e1117 45%, #0a0c10 100%); }
    .hero-title {
        background: linear-gradient(135deg, #EF4444 0%, #F97316 60%, #FACC15 100%);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        font-size: 2.4rem; font-weight: 800; margin-bottom: 0.2rem;
    }
    .hero-sub { color: #9CA3AF; margin-bottom: 1.5rem; }
    .stButton > button {
        background: linear-gradient(135deg, #DC2626 0%, #EA580C 100%) !important;
        color: white !important; border: none !important; border-radius: 10px !important;
        font-weight: 600 !important; padding: 0.6rem 1.4rem !important;
    }
    .disclaimer { color: #9CA3AF; font-size: 0.85rem; margin-top: 1rem; }
</style>
""",
    unsafe_allow_html=True,
)

st.markdown('<div class="hero-title">🚨 Disaster Response Multi-Agent System</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="hero-sub">Describe an incident. Specialist AI agents (analysis, rescue, hospital, '
    "location, resources) plan the response, and a verification agent checks it against emergency SOPs "
    "retrieved from the knowledge base.</div>",
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("🗂️ Incident History")
    try:
        rows = fetch_all_incidents()
    except Exception as e:
        rows = []
        st.warning(f"Could not load history: {e}")
    if not rows:
        st.caption("No incidents recorded yet.")
    for row in rows[:20]:
        rid, ts, scenario, description, severity, plan = row
        with st.expander(f"#{rid} · {scenario} · {severity}"):
            st.caption(ts)
            st.write(description)
            st.markdown(plan)

col1, col2 = st.columns(2)
scenario = col1.selectbox("Scenario type", SCENARIOS)
severity = col2.selectbox("Severity (your assessment)", SEVERITIES, index=2)

incident = st.text_area(
    "Incident report",
    height=140,
    placeholder="e.g. Chemical leak at a factory in Lahore. Around 40 workers affected, "
    "some with breathing difficulty. Fire spreading near storage tanks.",
)

st.markdown("**📍 Location**")
loc_col1, loc_col2 = st.columns([2, 1])
manual_location = loc_col1.text_input(
    "Address / landmark (optional)",
    placeholder="e.g. Gulberg III, near Liberty Market, Lahore",
)
lat = lon = accuracy = None
with loc_col2:
    st.caption("Or share your device location")
    if streamlit_geolocation is None:
        st.info("Install it with: pip install streamlit-geolocation")
    else:
        geo = streamlit_geolocation()
        if isinstance(geo, dict) and geo.get("latitude") is not None:
            lat, lon, accuracy = geo["latitude"], geo["longitude"], geo.get("accuracy")

if lat is not None:
    msg = f"Location captured: {lat:.5f}, {lon:.5f}"
    if accuracy is not None:
        msg += f" (accuracy about {accuracy:.0f} m)"
    st.success(msg)
    st.markdown(f"[Open in Google Maps](https://www.google.com/maps?q={lat},{lon})")
    if accuracy is not None and accuracy > 1000:
        st.warning("Accuracy is low (laptops often estimate location from Wi-Fi/IP). "
                   "Add an address or landmark above for a better result.")
    st.map({"lat": [lat], "lon": [lon]})

if st.button("Run Multi-Agent Analysis"):
    if not incident.strip():
        st.warning("Please describe the incident first.")
    else:
        report = incident.strip()
        location_lines = []
        if manual_location.strip():
            location_lines.append(f"Reported location: {manual_location.strip()}")
        if lat is not None:
            line = f"Reporter device coordinates: {lat:.5f}, {lon:.5f}"
            if accuracy is not None:
                line += f" (accuracy about {accuracy:.0f} m)"
            location_lines.append(line)
        if location_lines:
            report += "\n\n" + "\n".join(location_lines)
        try:
            with st.spinner("Agents are analysing the incident and checking SOPs..."):
                st.session_state.result = run_disaster_response(report)
            try:
                save_incident(
                    scenario,
                    report,
                    severity,
                    st.session_state.result.get("final_response", ""),
                )
            except Exception as e:
                st.warning(f"Response generated, but it could not be saved to history: {e}")
        except Exception as e:
            msg = str(e)
            if "429" in msg or "RESOURCE_EXHAUSTED" in msg:
                st.error("Gemini quota exhausted for this model. Wait for the quota to reset, "
                         "or set a different GEMINI_MODEL in .env.")
            elif "503" in msg or "UNAVAILABLE" in msg:
                st.error("Gemini is temporarily overloaded. Please try again in a minute.")
            else:
                st.error(f"Error: {msg}")

result = st.session_state.get("result")
if result:
    st.subheader("✅ Final Verified Response")
    with st.container(border=True):
        st.markdown(result.get("final_response", "No response generated."))

    st.subheader("🤖 Agent Outputs")
    tabs = st.tabs([label for label, _ in AGENT_TABS])
    for tab, (_, key) in zip(tabs, AGENT_TABS):
        with tab:
            content = result.get(key, "Not available.")
            if key == "retrieved_sops":
                st.text(content)
            else:
                st.markdown(content)

st.markdown(
    '<div class="disclaimer">Decision support only. Emergency authorities must verify field '
    "conditions and lead the response.</div>",
    unsafe_allow_html=True,
)