from pathlib import Path

def test_required_files_exist():
    assert Path("requirements.txt").exists()
    assert Path(".env").exists()
    assert Path("backend/main.py").exists()
    assert Path("backend/workflow/graph.py").exists()
