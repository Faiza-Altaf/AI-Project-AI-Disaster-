from fastapi import FastAPI
from pydantic import BaseModel
from backend.workflow.graph import run_disaster_response

app = FastAPI(
    title="AI Disaster Response Multi-Agent API",
    version="1.0.0"
)

class IncidentRequest(BaseModel):
    incident: str

@app.get("/")
def root():
    return {"project": "AI Disaster Response Multi-Agent System", "status": "running"}

@app.post("/analyze")
def analyze(request: IncidentRequest):
    result = run_disaster_response(request.incident)
    return result
