from backend.llm.model import get_llm

def location_agent(incident, incident_analysis) -> str:
    prompt = f'''
You are the Location/GIS Agent.
Extract the location and identify location-related coordination actions.
Do not claim live map data or exact coordinates unless provided.

Incident:
{incident}

Incident analysis:
{incident_analysis}
'''
    return get_llm().invoke(prompt).content
