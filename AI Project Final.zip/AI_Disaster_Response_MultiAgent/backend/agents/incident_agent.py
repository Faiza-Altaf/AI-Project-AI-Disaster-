from backend.llm.model import get_llm

def incident_agent(incident: str) -> str:
    prompt = f'''
You are the Incident Analysis Agent in a disaster response system.
Analyze this report and return:
- disaster type
- location
- people affected
- injuries
- urgency
- immediate concerns
Do not invent facts; say "Not provided" when information is missing.

Incident:
{incident}
'''
    return get_llm().invoke(prompt).content
