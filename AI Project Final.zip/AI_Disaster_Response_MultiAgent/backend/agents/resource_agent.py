from backend.llm.model import get_llm

def resource_agent(incident, rescue_plan, hospital_plan, location_plan) -> str:
    prompt = f'''
You are the Resource Coordination Agent.
Combine the specialist outputs and create a prioritized resource checklist.
Mark items as required, recommended, or needing confirmation.

Incident:
{incident}

Rescue:
{rescue_plan}

Hospital:
{hospital_plan}

Location:
{location_plan}
'''
    return get_llm().invoke(prompt).content
