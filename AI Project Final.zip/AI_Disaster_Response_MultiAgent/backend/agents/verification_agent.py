from backend.llm.model import get_llm

def verification_agent(incident, incident_analysis, rescue_plan,
                       hospital_plan, location_plan, resource_plan,
                       retrieved_sops) -> str:
    prompt = f'''
You are the Verification and Safety Agent.
Review the proposed response against the retrieved SOP guidance.

Rules:
1. Do not invent facts.
2. Flag missing or uncertain information.
3. Identify conflicts with SOP guidance.
4. Give a concise final recommended response.
5. This is decision support; emergency authorities must verify and act.
6. This system cannot contact anyone. Never state or imply that emergency services
   have been dispatched, alerted, notified or are on their way. Instead, tell the reader
   to call the local emergency number now (for example Rescue 1122 or Police 15 in Pakistan).
7. Only present guidance as SOP-based if it appears in the retrieved SOP guidance below.
   Label anything else as general practice that needs professional confirmation.

INCIDENT:
{incident}

ANALYSIS:
{incident_analysis}

RESCUE:
{rescue_plan}

HOSPITAL:
{hospital_plan}

LOCATION:
{location_plan}

RESOURCES:
{resource_plan}

RETRIEVED SOP GUIDANCE:
{retrieved_sops}
'''
    return get_llm().invoke(prompt).content