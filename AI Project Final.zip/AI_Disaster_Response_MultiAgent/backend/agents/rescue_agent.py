from backend.llm.model import get_llm

def rescue_agent(incident, incident_analysis) -> str:
    prompt = f'''
You are the Rescue Coordination Agent.
Identify rescue actions and resources that may be needed.
Separate confirmed information from assumptions. Do not invent facts.

Incident:
{incident}

Incident analysis:
{incident_analysis}
'''
    return get_llm().invoke(prompt).content
