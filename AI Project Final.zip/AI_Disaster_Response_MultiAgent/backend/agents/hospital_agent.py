from backend.llm.model import get_llm

def hospital_agent(incident, incident_analysis) -> str:
    prompt = f'''
You are the Hospital Coordination Agent.
Determine medical needs, ambulance requirements, triage priorities,
and hospital coordination requirements. Do not invent live hospital availability.

Incident:
{incident}

Incident analysis:
{incident_analysis}
'''
    return get_llm().invoke(prompt).content
