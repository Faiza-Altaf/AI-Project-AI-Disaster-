from pathlib import Path
from langchain_core.documents import Document

def load_sop_documents(sop_dir: Path):
    docs = []
    for path in sorted(sop_dir.glob("*.txt")):
        docs.append(Document(
            page_content=path.read_text(encoding="utf-8"),
            metadata={"source": path.name, "type": "emergency_sop"}
        ))
    if not docs:
        raise FileNotFoundError(f"No SOP files found in {sop_dir}")
    return docs
