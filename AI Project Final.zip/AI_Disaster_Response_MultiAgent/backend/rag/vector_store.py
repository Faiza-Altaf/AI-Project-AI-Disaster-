from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone
from backend.config import PINECONE_API_KEY, PINECONE_INDEX_NAME, SOP_DIR
from backend.rag.embeddings import get_embeddings
from backend.rag.document_loader import load_sop_documents
from backend.rag.text_splitter import split_documents

def get_vector_store():
    pc = Pinecone(api_key=PINECONE_API_KEY)
    return PineconeVectorStore(
        index_name=PINECONE_INDEX_NAME,
        embedding=get_embeddings()
    )

def build_vector_store():
    chunks = split_documents(load_sop_documents(SOP_DIR))
    store = PineconeVectorStore.from_documents(
        documents=chunks,
        embedding=get_embeddings(),
        index_name=PINECONE_INDEX_NAME
    )
    return store, len(chunks)