from langchain_google_genai import GoogleGenerativeAIEmbeddings
from backend.config import EMBEDDING_MODEL, EMBEDDING_DIMENSIONS, GOOGLE_API_KEY, validate_config

def get_embeddings():
    validate_config()
    return GoogleGenerativeAIEmbeddings(
        model=EMBEDDING_MODEL,
        google_api_key=GOOGLE_API_KEY,
        output_dimensionality=EMBEDDING_DIMENSIONS
    )