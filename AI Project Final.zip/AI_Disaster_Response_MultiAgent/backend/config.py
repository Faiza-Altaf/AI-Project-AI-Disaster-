from pathlib import Path
import os
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(ROOT_DIR / ".env")

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "models/gemini-3.1-flash-lite")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "models/gemini-embedding-001")
EMBEDDING_DIMENSIONS = int(os.getenv("EMBEDDING_DIMENSIONS", "1024"))

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY", "")
PINECONE_INDEX_NAME = os.getenv("PINECONE_INDEX_NAME", "")

SOP_DIR = ROOT_DIR / "backend" / "data" / "emergency_sops"

def validate_config():
    if not GOOGLE_API_KEY or GOOGLE_API_KEY == "your_google_api_key_here":
        raise RuntimeError("GOOGLE_API_KEY is missing. Add your API key to .env.")
    if not PINECONE_API_KEY or PINECONE_API_KEY == "your_pinecone_api_key_here":
        raise RuntimeError("PINECONE_API_KEY is missing. Add your API key to .env.")
    if not PINECONE_INDEX_NAME:
        raise RuntimeError("PINECONE_INDEX_NAME is missing. Add it to .env.")