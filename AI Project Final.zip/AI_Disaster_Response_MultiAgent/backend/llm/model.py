from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableLambda
from langchain_google_genai import ChatGoogleGenerativeAI
from backend.config import GOOGLE_API_KEY, GEMINI_MODEL, validate_config


def _to_text(content) -> str:
    """Gemini 3.x can return a list of content blocks; flatten it to plain text."""
    if isinstance(content, str):
        return content
    parts = []
    for block in content:
        if isinstance(block, str):
            parts.append(block)
        elif isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
    return "".join(parts)


def _normalize(message) -> AIMessage:
    return AIMessage(content=_to_text(message.content))


def get_llm():
    validate_config()
    llm = ChatGoogleGenerativeAI(
        model=GEMINI_MODEL,
        temperature=0,
        google_api_key=GOOGLE_API_KEY
    )
    # Agents call get_llm().invoke(prompt).content and always get a plain string.
    return llm | RunnableLambda(_normalize)
