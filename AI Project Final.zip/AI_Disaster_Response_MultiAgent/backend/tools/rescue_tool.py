def rescue_request(location: str, emergency_type: str) -> str:
    return f"Rescue request prepared: {emergency_type} at {location}."
