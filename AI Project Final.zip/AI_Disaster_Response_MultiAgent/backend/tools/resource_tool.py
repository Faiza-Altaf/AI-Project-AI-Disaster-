def resource_check(resource: str) -> str:
    return f"Resource check requested for: {resource}."
