def hospital_lookup(location: str) -> str:
    return f"Hospital search requested for {location}. Live availability is not connected yet."
