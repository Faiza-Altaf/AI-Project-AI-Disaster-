def location_lookup(location: str) -> str:
    return f"Location received for GIS processing: {location}"
