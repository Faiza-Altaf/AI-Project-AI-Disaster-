from typing import TypedDict

class DisasterState(TypedDict, total=False):
    incident: str
    incident_analysis: str
    rescue_plan: str
    hospital_plan: str
    location_plan: str
    resource_plan: str
    retrieved_sops: str
    final_response: str
