from langgraph.graph import StateGraph, START, END
from backend.workflow.state import DisasterState
from backend.agents.incident_agent import incident_agent
from backend.agents.rescue_agent import rescue_agent
from backend.agents.hospital_agent import hospital_agent
from backend.agents.location_agent import location_agent
from backend.agents.resource_agent import resource_agent
from backend.agents.verification_agent import verification_agent
from backend.rag.retriever import retrieve_sops

def analyze_incident(state):
    return {"incident_analysis": incident_agent(state["incident"])}

def rescue(state):
    return {"rescue_plan": rescue_agent(state["incident"], state["incident_analysis"])}

def hospital(state):
    return {"hospital_plan": hospital_agent(state["incident"], state["incident_analysis"])}

def location(state):
    return {"location_plan": location_agent(state["incident"], state["incident_analysis"])}

def resources(state):
    return {"resource_plan": resource_agent(
        state["incident"], state["rescue_plan"],
        state["hospital_plan"], state["location_plan"]
    )}

def rag(state):
    docs = retrieve_sops(state["incident"] + "\n" + state["incident_analysis"])
    text = "\n\n".join(
        f'[{d.metadata.get("source", "unknown")}]\n{d.page_content}'
        for d in docs
    )
    return {"retrieved_sops": text}

def verify(state):
    return {"final_response": verification_agent(
        state["incident"], state["incident_analysis"],
        state["rescue_plan"], state["hospital_plan"],
        state["location_plan"], state["resource_plan"],
        state["retrieved_sops"]
    )}

def build_graph():
    g = StateGraph(DisasterState)
    g.add_node("incident_analysis", analyze_incident)
    g.add_node("rescue_agent", rescue)
    g.add_node("hospital_agent", hospital)
    g.add_node("location_agent", location)
    g.add_node("resource_agent", resources)
    g.add_node("rag", rag)
    g.add_node("verification_agent", verify)

    g.add_edge(START, "incident_analysis")
    g.add_edge("incident_analysis", "rescue_agent")
    g.add_edge("incident_analysis", "hospital_agent")
    g.add_edge("incident_analysis", "location_agent")
    g.add_edge("rescue_agent", "resource_agent")
    g.add_edge("hospital_agent", "resource_agent")
    g.add_edge("location_agent", "resource_agent")
    g.add_edge("resource_agent", "rag")
    g.add_edge("rag", "verification_agent")
    g.add_edge("verification_agent", END)
    return g.compile()

disaster_graph = build_graph()

def run_disaster_response(incident: str):
    return disaster_graph.invoke({"incident": incident})
