import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

print("Models that support generateContent (chat/LLM):\n")
for model in client.models.list():
    if "generateContent" in (model.supported_actions or []):
        print(f"  {model.name}")

print("\nModels that support embedContent (embeddings):\n")
for model in client.models.list():
    if "embedContent" in (model.supported_actions or []):
        print(f"  {model.name}")