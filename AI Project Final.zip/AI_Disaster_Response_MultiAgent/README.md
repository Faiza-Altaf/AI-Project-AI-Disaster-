# AI-Powered Disaster Response Multi-Agent System

This starter project demonstrates LangChain, RAG, LangGraph multi-agent orchestration, and a FastAPI backend.

## Setup

Windows CMD:
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Add your real OpenAI API key to `.env`.

Run:
```bat
python -m backend.main
```

API:
```bat
uvicorn backend.api.routes:app --reload
```

Open http://127.0.0.1:8000/docs

Example incident:
A severe flood has trapped 10 people in a building in Lahore. Two people are injured and an ambulance is needed.

The first RAG run creates a local Chroma database from the SOP files.
